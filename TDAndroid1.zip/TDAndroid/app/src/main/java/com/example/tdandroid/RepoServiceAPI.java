package com.example.tdandroid;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RepoServiceAPI {
    String BASE_URL = "http://127.0.0.1:8080/";

    @GET("ListeEtudiants/")
    Call<List<Etudiant>> affichage();
}
