package com.example.tdandroid;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "students.db";
    private static final int DATABASE_VERSION = 1;

    // Table name
    private static final String TABLE_NAME = "students";

    // Table columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CIN = "cin";
    private static final String COLUMN_NP = "np";
    private static final String COLUMN_CLASSE = "classe";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create table SQL query
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CIN + " TEXT, " +
                COLUMN_NP + " TEXT, " +
                COLUMN_CLASSE + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    // Method to add a student to the database
    public boolean addStudent(String cin, String np, String classe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CIN, cin);
        values.put(COLUMN_NP, np);
        values.put(COLUMN_CLASSE, classe);
        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1; // Return true if insert is successful
    }
}
