package com.example.tdandroid;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private EditText cin, np;
    private Button valider, afficher;
    private Spinner spinner;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> listItems = new ArrayList<>();

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Partie 2 : Code des références aux vues
        cin = findViewById(R.id.editTextText2);
        np = findViewById(R.id.editTextText3);
        valider = findViewById(R.id.button5);
        afficher = findViewById(R.id.button6);
        spinner = findViewById(R.id.spinner2);
        listView = findViewById(R.id.textView11); // Assurez-vous que vous avez un ListView dans votre layout

        // Initialize adapter for ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItems);
        listView.setAdapter(adapter);

        // Initialize Retrofit
        Retrofit retrofit = new Retrofit.Builder().baseUrl(RepoServiceAPI.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        RepoServiceAPI myApi = retrofit.create(RepoServiceAPI.class);

        afficher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call<List<Etudiant>> call = myApi.affichage();
                call.enqueue(new Callback<List<Etudiant>>() {
                    @Override
                    public void onResponse(Call<List<Etudiant>> call, Response<List<Etudiant>> response) {
                        if (response.isSuccessful()) {
                            List<Etudiant> etudiants = response.body();
                            listItems.clear(); // Clear previous items
                            for (Etudiant et : etudiants) {
                                listItems.add(et.getNom_prenom());
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(MainActivity.this, "Erreur de réponse", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Etudiant>> call, Throwable t) {
                        Log.e("ERROR", t.getMessage());
                        Toast.makeText(MainActivity.this, "Erreur de réseau", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
